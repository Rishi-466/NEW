
import React, { useState, useEffect } from 'react';
import InvitationCover from './components/InvitationCover';
import Gallery from './components/Gallery';
import Itinerary from './components/Itinerary';
import Venue from './components/Venue';
import Countdown from './components/Countdown';
import FloatingParticles from './components/FloatingParticles';
import Confetti from './components/Confetti';
import MusicPlayer from './components/MusicPlayer';
import SongRequests from './components/GuestBook';
import BlessingsAI from './components/Timeline';
import { COUPLE_NAMES, EVENT_DATE } from './constants';

const App: React.FC = () => {
  const [isInvitationOpen, setIsInvitationOpen] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const [showContent, setShowContent] = useState(false);

  const handleOpenInvitation = () => {
    setIsInvitationOpen(true);
    setShowConfetti(true);
    // Let the cover animation finish before showing content
    setTimeout(() => setShowContent(true), 500); 
    // Confetti lasts for 5 seconds
    setTimeout(() => setShowConfetti(false), 5000); 
  };
  
  // Preload gallery images
  useEffect(() => {
    // This is a simple preload, more robust solutions exist but this is good for this scope
    const galleryImages = [
      'https://picsum.photos/seed/couple1/1200/800',
      'https://picsum.photos/seed/couple2/1200/800',
      'https://picsum.photos/seed/couple3/1200/800',
      'https://picsum.photos/seed/couple4/1200/800'
    ];
    galleryImages.forEach((src) => {
      const img = new Image();
      img.src = src;
    });
  }, []);

  return (
    <div className="bg-[#fdfaf6] min-h-screen text-[#4A4A4A] relative overflow-x-hidden">
      <FloatingParticles />
      {showConfetti && <Confetti />}
      <MusicPlayer />
      
      <InvitationCover 
        isOpen={isInvitationOpen} 
        onOpen={handleOpenInvitation} 
        coupleNames={COUPLE_NAMES}
      />
      
      {showContent && (
        <main className={`transition-opacity duration-1000 ${isInvitationOpen ? 'opacity-100' : 'opacity-0'}`}>
          <header className="relative text-white text-center py-20 px-4 overflow-hidden bg-gradient-to-br from-[#0a2463] to-[#4169E1]">
             <div className="absolute inset-0 bg-black opacity-30"></div>
             <div className="relative z-10">
                <h2 className="text-xl md:text-2xl font-light tracking-wider">We're Getting Engaged!</h2>
                <h1 className="font-great-vibes text-6xl md:text-8xl my-4 animate-shimmer bg-gradient-to-r from-rose-200 to-yellow-200">{COUPLE_NAMES.join(' & ')}</h1>
                <p className="text-lg md:text-xl font-light tracking-wide">Join us to celebrate our love</p>
             </div>
          </header>

          <Countdown targetDate={EVENT_DATE} />
          
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-24 my-24">
            <Gallery />
            <BlessingsAI />
            <Itinerary />
            <SongRequests />
            <Venue />
          </div>

          <footer className="text-center py-12 bg-gradient-to-t from-[#f7e7ce] to-[#fdfaf6]">
            <p className="font-great-vibes text-4xl text-[#B76E79]">With Love,</p>
            <p className="text-2xl mt-2 font-semibold text-[#4169E1]">{COUPLE_NAMES.join(' & ')}</p>
          </footer>
        </main>
      )}
    </div>
  );
};

export default App;