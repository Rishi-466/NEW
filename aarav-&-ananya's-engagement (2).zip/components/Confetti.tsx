
import React from 'react';

const Confetti: React.FC = () => {
  const confettiPieces = Array.from({ length: 100 });

  const confettiStyles = confettiPieces.map(() => {
    const colors = ['#4169E1', '#B76E79', '#f7e7ce', '#FFFFFF'];
    return {
      left: `${Math.random() * 100}vw`,
      animationDuration: `${Math.random() * 3 + 2}s`, // 2 to 5 seconds
      animationDelay: `${Math.random() * 0.5}s`,
      backgroundColor: colors[Math.floor(Math.random() * colors.length)],
      transform: `rotate(${Math.random() * 360}deg)`,
      width: `${Math.random() * 8 + 6}px`,
      height: `${Math.random() * 8 + 6}px`,
    };
  });

  return (
    <div className="fixed top-0 left-0 w-full h-full pointer-events-none z-50 overflow-hidden">
      <style>{`
        @keyframes fall {
          0% {
            opacity: 1;
            transform: translateY(-10vh) rotate(0deg);
          }
          100% {
            opacity: 0;
            transform: translateY(110vh) rotate(720deg);
          }
        }
        .confetti-piece {
          position: absolute;
          top: -10vh;
          will-change: transform, opacity;
          animation-name: fall;
          animation-timing-function: linear;
          animation-fill-mode: forwards;
        }
      `}</style>
      {confettiStyles.map((style, i) => (
        <div key={i} className="confetti-piece rounded-full" style={style}></div>
      ))}
    </div>
  );
};

export default Confetti;
