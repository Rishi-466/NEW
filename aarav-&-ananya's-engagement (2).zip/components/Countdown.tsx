
import React from 'react';
import useCountdown from '../hooks/useCountdown';

interface CountdownProps {
  targetDate: string;
}

const TimeCard: React.FC<{ value: number; label: string }> = ({ value, label }) => (
  <div className="flex flex-col items-center">
    <div className="w-24 h-24 sm:w-28 sm:h-28 flex items-center justify-center bg-white/10 glassmorphism rounded-2xl shadow-lg">
      <span className="text-5xl sm:text-6xl font-bold text-white tracking-wider">{String(value).padStart(2, '0')}</span>
    </div>
    <span className="mt-3 text-lg sm:text-xl font-semibold text-white/80">{label}</span>
  </div>
);


const Countdown: React.FC<CountdownProps> = ({ targetDate }) => {
  const { days, hours, minutes, seconds, isTimeUp } = useCountdown(targetDate);

  if (isTimeUp) {
    return (
        <div className="bg-[#4169E1]/80 py-12 -mt-16 relative z-20 shadow-xl">
            <div className="text-center text-white">
                <h2 className="text-4xl font-bold">The Celebration has begun!</h2>
            </div>
        </div>
    );
  }

  return (
    <div className="bg-[#4169E1]/80 py-12 -mt-16 relative z-20 shadow-xl backdrop-blur-sm">
      <div className="max-w-3xl mx-auto flex justify-center items-start space-x-3 sm:space-x-6 text-center">
        <TimeCard value={days} label="Days" />
        <TimeCard value={hours} label="Hours" />
        <TimeCard value={minutes} label="Minutes" />
        <TimeCard value={seconds} label="Seconds" />
      </div>
    </div>
  );
};

export default Countdown;
