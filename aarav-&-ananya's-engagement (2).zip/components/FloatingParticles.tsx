
import React from 'react';

const FloatingParticles: React.FC = () => {
  const particles = Array.from({ length: 15 }); // Create 15 heart particles

  const particleStyles = particles.map((_, i) => ({
    left: `${Math.random() * 100}%`,
    animationDuration: `${Math.random() * 10 + 5}s`, // 5 to 15 seconds
    animationDelay: `${Math.random() * 5}s`,
    opacity: Math.random() * 0.5 + 0.2, // 0.2 to 0.7
    transform: `scale(${Math.random() * 0.6 + 0.4})`, // 0.4 to 1.0
  }));

  return (
    <div className="fixed top-0 left-0 w-full h-full pointer-events-none z-0 overflow-hidden">
      {/* CSS for the animation is in a style tag to use the calculated values */}
      <style>{`
        @keyframes float {
          0% {
            transform: translateY(100vh) rotate(0deg);
          }
          100% {
            transform: translateY(-10vh) rotate(360deg);
          }
        }
        .particle {
          position: absolute;
          bottom: -10vh;
          will-change: transform;
          animation-name: float;
          animation-timing-function: linear;
          animation-iteration-count: infinite;
        }
      `}</style>
      {particleStyles.map((style, i) => (
        <div key={i} className="particle" style={style}>
          <svg className="w-8 h-8 text-[#B76E79]" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd"></path>
          </svg>
        </div>
      ))}
    </div>
  );
};

export default FloatingParticles;
