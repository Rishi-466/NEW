
import React, { useState, useEffect, useCallback } from 'react';
import Section from './Section';
import { GALLERY_IMAGES } from '../constants';
import { ChevronLeftIcon, ChevronRightIcon } from './icons/Icons';

const Gallery: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextSlide = useCallback(() => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % GALLERY_IMAGES.length);
  }, []);

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + GALLERY_IMAGES.length) % GALLERY_IMAGES.length);
  };

  useEffect(() => {
    const slideInterval = setInterval(nextSlide, 5000); // Change slide every 5 seconds
    return () => clearInterval(slideInterval);
  }, [nextSlide]);

  return (
    <Section title="Our Moments" subtitle="A Glimpse into Our Journey">
      <div className="relative w-full max-w-4xl mx-auto aspect-w-16 aspect-h-9 rounded-lg shadow-2xl overflow-hidden group">
        <div className="relative h-[500px] w-full overflow-hidden">
          {GALLERY_IMAGES.map((src, index) => (
            <img
              key={src}
              src={src}
              alt={`Couple moment ${index + 1}`}
              className={`absolute top-0 left-0 w-full h-full object-cover transition-opacity duration-1000 ease-in-out ${
                index === currentIndex ? 'opacity-100' : 'opacity-0'
              }`}
            />
          ))}
        </div>
        
        <button
          onClick={prevSlide}
          className="absolute top-1/2 left-4 -translate-y-1/2 bg-white/30 text-white p-3 rounded-full hover:bg-white/50 transition-all opacity-0 group-hover:opacity-100 duration-300"
        >
          <ChevronLeftIcon className="w-6 h-6" />
        </button>
        <button
          onClick={nextSlide}
          className="absolute top-1/2 right-4 -translate-y-1/2 bg-white/30 text-white p-3 rounded-full hover:bg-white/50 transition-all opacity-0 group-hover:opacity-100 duration-300"
        >
          <ChevronRightIcon className="w-6 h-6" />
        </button>

        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2">
            {GALLERY_IMAGES.map((_, index) => (
                <div
                    key={index}
                    onClick={() => setCurrentIndex(index)}
                    className={`w-3 h-3 rounded-full cursor-pointer transition-all duration-300 ${index === currentIndex ? 'bg-white scale-125' : 'bg-white/50 hover:bg-white'}`}
                ></div>
            ))}
        </div>
      </div>
    </Section>
  );
};

export default Gallery;
