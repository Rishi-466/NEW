
import React, { useState } from 'react';
import Section from './Section';
import { MusicIcon } from './icons/Icons';

interface SongRequest {
  name: string;
  song: string;
}

const SongRequests: React.FC = () => {
  const [requests, setRequests] = useState<SongRequest[]>([
    { name: 'Rohan', song: 'Morni Banke - Guru Randhawa' },
    { name: 'Priya Aunty', song: 'Kala Chashma - Badshah' },
    { name: 'Arjun', song: 'Ghungroo - Arijit Singh, Shilpa Rao' }
  ]);
  const [name, setName] = useState('');
  const [song, setSong] = useState('');
  const [error, setError] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !song.trim()) {
      setError('Please fill out both your name and your song request.');
      return;
    }
    const newRequest = { name, song };
    setRequests([newRequest, ...requests]);
    setName('');
    setSong('');
    setError('');
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  return (
    <Section title="Sangeet Song Requests" subtitle="Help Us Build The Perfect Playlist!">
      <div className="max-w-2xl mx-auto space-y-8">
        <div className="p-6 md:p-8 rounded-2xl glassmorphism bg-gradient-to-br from-[#4169E1]/10 to-blue-300/10 shadow-xl">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="name" className="sr-only">Your Name</label>
              <input
                type="text"
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Your Name"
                className="w-full px-4 py-3 rounded-lg bg-white/70 border border-white/50 focus:ring-2 focus:ring-[#B76E79] focus:outline-none transition-all placeholder-gray-500"
                aria-label="Your Name"
              />
            </div>
            <div>
              <label htmlFor="song" className="sr-only">Song Title & Artist</label>
              <textarea
                id="song"
                rows={2}
                value={song}
                onChange={(e) => setSong(e.target.value)}
                placeholder="Share a song that will get you on the dance floor..."
                className="w-full px-4 py-3 rounded-lg bg-white/70 border border-white/50 focus:ring-2 focus:ring-[#B76E79] focus:outline-none transition-all placeholder-gray-500"
                aria-label="Your Song Request"
              />
            </div>
            {error && <p className="text-red-500 text-sm" role="alert">{error}</p>}
            {submitted && <p className="text-green-600 text-center font-semibold" role="status">Thanks! We've added your song to the list.</p>}
            <button
              type="submit"
              className="w-full px-8 py-3 bg-[#B76E79] text-white rounded-full text-lg font-semibold transition-all duration-300 hover:bg-[#a35d67] hover:scale-105 hover:shadow-lg focus:outline-none focus:ring-4 focus:ring-[#B76E79]/50"
            >
              Request Song
            </button>
          </form>
        </div>

        <div className="space-y-4">
          <h3 className="text-2xl font-bold text-center text-[#4169E1] tracking-wide">Guest Playlist</h3>
          <div className="space-y-3">
            {requests.map((request, index) => (
              <div
                key={index}
                className="bg-white/90 p-4 rounded-xl shadow-md animate-fade-in-up flex items-center space-x-4 border-l-4 border-[#4169E1]"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="p-3 bg-[#f7e7ce] rounded-full">
                    <MusicIcon className="w-6 h-6 text-[#B76E79]" />
                </div>
                <div className="text-left flex-grow">
                  <p className="font-semibold text-gray-700">{request.song}</p>
                  <p className="text-sm text-gray-500 italic">Requested by: {request.name}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Section>
  );
};

export default SongRequests;
