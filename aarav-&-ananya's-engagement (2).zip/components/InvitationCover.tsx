
import React from 'react';
import { HeartIcon } from './icons/Icons';

interface InvitationCoverProps {
  isOpen: boolean;
  onOpen: () => void;
  coupleNames: [string, string];
}

const InvitationCover: React.FC<InvitationCoverProps> = ({ isOpen, onOpen, coupleNames }) => {
  return (
    <div
      className={`fixed inset-0 bg-gradient-to-br from-[#0a2463] to-[#4169E1] z-50 flex items-center justify-center transition-all duration-1000 ease-in-out ${
        isOpen ? 'opacity-0 -translate-y-full' : 'opacity-100'
      }`}
      style={{ pointerEvents: isOpen ? 'none' : 'auto' }}
    >
      <div 
        className="text-center text-white p-8 cursor-pointer group"
        onClick={onOpen}
      >
        <p className="text-2xl font-light tracking-widest mb-4">You're Invited</p>
        <div className="flex items-center justify-center space-x-4 md:space-x-6">
            <h1 className="font-great-vibes text-7xl md:text-9xl animate-shimmer">{coupleNames[0]}</h1>
            <HeartIcon className="w-10 h-10 md:w-16 md:h-16 text-[#B76E79] shrink-0" />
            <h1 className="font-great-vibes text-7xl md:text-9xl animate-shimmer">{coupleNames[1]}</h1>
        </div>
        <div className="mt-12">
            <button 
              className="px-8 py-3 bg-white/20 border border-white/50 rounded-full text-lg backdrop-blur-sm transition-all duration-300 group-hover:bg-white/30 group-hover:scale-105 group-hover:shadow-lg"
              onClick={onOpen}
            >
              Click to Open
            </button>
        </div>
      </div>
    </div>
  );
};

export default InvitationCover;
