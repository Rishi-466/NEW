
import React, { useState } from 'react';
import Section from './Section';
import { ITINERARY_ITEMS } from '../constants';
import { ChevronDownIcon } from './icons/Icons';

const Itinerary: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const handleToggle = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <Section title="The Celebration" subtitle="Schedule of Events">
      <div className="max-w-2xl mx-auto space-y-4">
        {ITINERARY_ITEMS.map((item, index) => (
          <div key={index} className="rounded-lg shadow-lg overflow-hidden border border-rose-100 bg-white">
            <button
              onClick={() => handleToggle(index)}
              className="w-full flex justify-between items-center p-6 text-left"
            >
              <div className="flex items-center space-x-4">
                <div className="p-3 bg-[#f7e7ce] rounded-full">
                  <item.icon className="w-6 h-6 text-[#B76E79]" />
                </div>
                <div>
                    <h3 className="text-xl font-bold text-[#4169E1]">{item.title}</h3>
                    <p className="text-sm text-gray-500">{item.time}</p>
                </div>
              </div>
              <ChevronDownIcon
                className={`w-6 h-6 text-gray-500 transition-transform duration-300 ${
                  openIndex === index ? 'rotate-180' : ''
                }`}
              />
            </button>
            <div
              className={`grid transition-all duration-500 ease-in-out ${
                openIndex === index ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'
              }`}
            >
              <div className="overflow-hidden">
                <p className="px-6 pb-6 pt-0 text-left text-gray-600">
                  {item.description}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
};

export default Itinerary;
