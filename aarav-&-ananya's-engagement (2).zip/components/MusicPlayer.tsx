
import React, { useState, useRef, useEffect } from 'react';
import { MusicOnIcon, MusicOffIcon } from './icons/Icons';

const MusicPlayer: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);
  
  // A royalty-free romantic music piece
  const musicSrc = 'https://cdn.pixabay.com/download/audio/2022/02/14/audio_071891398c.mp3';

  const togglePlayPause = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play().catch(error => {
          console.error("Audio playback failed:", error);
          // Autoplay might be blocked, user interaction is required.
          setIsPlaying(false);
        });
      }
      setIsPlaying(!isPlaying);
    }
  };

  // Attempt to autoplay when component mounts, respecting browser policies
  useEffect(() => {
    if (audioRef.current) {
        audioRef.current.play().then(() => {
            setIsPlaying(true);
        }).catch(() => {
            setIsPlaying(false);
        });
    }
  }, []);

  return (
    <>
      <audio ref={audioRef} src={musicSrc} loop />
      <button
        onClick={togglePlayPause}
        className="fixed bottom-4 right-4 z-40 bg-white/20 text-white p-3 rounded-full backdrop-blur-sm shadow-lg hover:bg-white/30 transition-all"
        aria-label={isPlaying ? 'Pause Music' : 'Play Music'}
      >
        {isPlaying ? <MusicOnIcon className="w-6 h-6" /> : <MusicOffIcon className="w-6 h-6" />}
      </button>
    </>
  );
};

export default MusicPlayer;
