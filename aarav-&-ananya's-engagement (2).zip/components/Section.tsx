
import React from 'react';

interface SectionProps {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}

const Section: React.FC<SectionProps> = ({ title, subtitle, children }) => {
  return (
    <section className="text-center animate-fade-in-up">
      {subtitle && <p className="text-lg text-[#B76E79] font-medium">{subtitle}</p>}
      <h2 className="font-great-vibes text-6xl md:text-7xl text-[#4169E1] mb-8">{title}</h2>
      {children}
    </section>
  );
};

export default Section;
