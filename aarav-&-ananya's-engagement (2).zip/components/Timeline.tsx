
import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import Section from './Section';
import { SparkleIcon } from './icons/Icons';
import { COUPLE_NAMES } from '../constants';

const BlessingsAI: React.FC = () => {
    const [blessing, setBlessing] = useState<string>('');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string>('');

    const handleGenerateBlessing = async () => {
        setIsLoading(true);
        setError('');
        setBlessing('');

        try {
            if (!process.env.API_KEY) {
                throw new Error("API key is missing.");
            }
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const prompt = `You are a warm and eloquent well-wisher at an Indian engagement party for a couple named ${COUPLE_NAMES[0]} and ${COUPLE_NAMES[1]}. Generate a unique and heartfelt, two-line poetic blessing for them. The tone should be celebratory, auspicious, and modern. Do not use markdown or add introductory text like 'Here is a blessing:'.`;
            
            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash",
                contents: prompt,
            });
            
            setBlessing(response.text);

        } catch (e) {
            console.error(e);
            setError('Could not generate a blessing at this moment. Please try again later.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Section title="A Wish For Us" subtitle="From The Stars, To Our Hearts">
            <div className="max-w-2xl mx-auto p-6 md:p-8 rounded-2xl glassmorphism bg-gradient-to-br from-[#4169E1]/10 to-blue-300/10 shadow-xl text-center">
                <div 
                    className="min-h-[100px] flex items-center justify-center p-4 mb-6 bg-white/50 rounded-lg"
                    aria-live="polite"
                >
                    {isLoading ? (
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#B76E79]"></div>
                    ) : error ? (
                        <p className="text-red-600 font-medium">{error}</p>
                    ) : blessing ? (
                        <div className="text-center">
                            {blessing.split('\n').map((line, index) => (
                                <p key={index} className="text-xl italic text-gray-700 font-medium">{line}</p>
                            ))}
                        </div>
                    ) : (
                         <p className="text-lg text-gray-600">Click the button to receive a special blessing for {COUPLE_NAMES.join(' & ')}!</p>
                    )}
                </div>

                <button
                    onClick={handleGenerateBlessing}
                    disabled={isLoading}
                    className="inline-flex items-center gap-3 px-8 py-3 bg-[#B76E79] text-white rounded-full text-lg font-semibold transition-all duration-300 hover:bg-[#a35d67] hover:scale-105 hover:shadow-lg focus:outline-none focus:ring-4 focus:ring-[#B76E79]/50 disabled:bg-gray-400 disabled:scale-100 disabled:cursor-not-allowed"
                >
                    <SparkleIcon className="w-6 h-6" />
                    {blessing ? 'Generate Another' : 'Generate a Blessing'}
                </button>
            </div>
        </Section>
    );
};

export default BlessingsAI;