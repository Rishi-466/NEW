import React from 'react';
import Section from './Section';
import { LocationIcon } from './icons/Icons';

const Venue: React.FC = () => {
  return (
    <Section title="The Venue" subtitle="Where We'll Say 'Yes'">
      <div className="max-w-4xl mx-auto p-4 md:p-6 rounded-2xl glassmorphism bg-gradient-to-br from-[#4169E1]/20 to-blue-300/20 shadow-xl">
        <div className="rounded-lg overflow-hidden shadow-lg">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15331.06677940177!2d81.58334813589637!3d16.59154784462159!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a3632f5f6379c33%3A0x6a96f33333917812!2sVendra%2C%20Andhra%20Pradesh%20534210!5e0!3m2!1sen!2sin!4v1716305333793!5m2!1sen!2sin"
            width="100%"
            height="450"
            style={{ border: 0 }}
            allowFullScreen={true}
            loading="lazy"
            title="Venue Map"
          ></iframe>
        </div>
        <div className="text-center mt-6 text-[#0a2463]">
            <div className="flex justify-center items-center gap-2">
                <LocationIcon className="w-6 h-6"/>
                <h3 className="text-2xl font-bold">Vendra Gardens</h3>
            </div>
            <p className="mt-1 text-lg">Vendra, Bhimavaram, Andhra Pradesh 534210</p>
        </div>
      </div>
    </Section>
  );
};

export default Venue;