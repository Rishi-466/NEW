
import React from 'react';
import { MusicIcon, RingIcon, FoodIcon, HeartIcon } from './components/icons/Icons';

export const COUPLE_NAMES: [string, string] = ['Kittu', 'Vinni'];
export const EVENT_DATE: string = '2025-08-10T18:00:00';

export const GALLERY_IMAGES: string[] = [
    'https://picsum.photos/seed/couple1/1200/800',
    'https://picsum.photos/seed/couple2/1200/800',
    'https://picsum.photos/seed/couple3/1200/800',
    'https://picsum.photos/seed/couple4/1200/800'
];

export const ITINERARY_ITEMS = [
    {
        icon: MusicIcon,
        title: 'Sangeet & Cocktails',
        time: 'August 9, 2025 | 7:00 PM onwards',
        description: 'Join us for a vibrant evening of music, dance, and celebration to kick off the festivities.'
    },
    {
        icon: RingIcon,
        title: 'Engagement Ceremony',
        time: 'August 10, 2025 | 6:00 PM - 8:00 PM',
        description: 'The auspicious moment when we exchange rings and officially begin our journey to forever.'
    },
    {
        icon: FoodIcon,
        title: 'Celebratory Dinner',
        time: 'August 10, 2025 | 8:00 PM onwards',
        description: 'A grand feast to celebrate our union. We look forward to dining and celebrating with you.'
    }
];